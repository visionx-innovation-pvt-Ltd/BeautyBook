@echo off
echo ========================================
echo   BeautyBook - Creating Complete Package
echo ========================================
echo.

:: Create package name with timestamp
set PACKAGE_NAME=BeautyBook_Complete_Package_%date:~-4,4%%date:~-10,2%%date:~-7,2%

echo Creating ZIP package: %PACKAGE_NAME%.zip
echo.

:: Check if PowerShell is available
where powershell >nul 2>&1
if %errorlevel% == 0 (
    echo Using PowerShell to create ZIP...
    powershell -Command "Compress-Archive -Path '*.html','*.css','*.js','*.json','*.txt','*.md','*.bat','*.sh','assets' -DestinationPath '%PACKAGE_NAME%.zip' -Force"
    echo.
    echo ✅ Package created successfully!
    echo 📦 File: %PACKAGE_NAME%.zip
    echo 📍 Location: %cd%
    echo.
    echo Opening folder...
    explorer .
) else (
    echo PowerShell not found. Please manually ZIP the following files:
    echo - index.html
    echo - styles.css
    echo - script.js
    echo - manifest.json
    echo - sw.js
    echo - package.json
    echo - All .md files
    echo - All .txt files
    echo - assets folder
)

echo.
echo ========================================
echo   Press any key to exit...
echo ========================================
pause >nul
