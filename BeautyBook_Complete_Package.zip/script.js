// ====================================
// BeautyBook - Main Application Script
// AI-Powered Hair Salon Booking Platform
// ====================================

// ===== Global State =====
const appState = {
  user: null,
  selectedBrand: null,
  selectedServices: [],
  selectedDate: null,
  selectedTime: null,
  selectedHairstyle: null,
  selectedColor: "natural",
  hairLength: 50,
  styleIntensity: 70,
  paymentMethod: "online",
  cameraActive: false,
  faceDetected: false,
  webcamStream: null,
  model: null,
  bookingData: {},
};

// ===== Brand Data =====
const brands = [
  {
    id: 1,
    name: "Luxe Salon",
    icon: "💎",
    description: "Premium luxury salon experience",
    rating: 4.9,
    reviews: 1250,
    locations: 15,
  },
  {
    id: 2,
    name: "Style Studio",
    icon: "✨",
    description: "Modern cuts and styling",
    rating: 4.8,
    reviews: 980,
    locations: 12,
  },
  {
    id: 3,
    name: "Beauty Haven",
    icon: "🌸",
    description: "Complete beauty solutions",
    rating: 4.7,
    reviews: 850,
    locations: 10,
  },
  {
    id: 4,
    name: "Glamour Zone",
    icon: "👑",
    description: "Celebrity-style makeovers",
    rating: 4.9,
    reviews: 1450,
    locations: 18,
  },
  {
    id: 5,
    name: "Trendy Cuts",
    icon: "✂️",
    description: "Latest trending styles",
    rating: 4.6,
    reviews: 720,
    locations: 8,
  },
  {
    id: 6,
    name: "Elite Hair",
    icon: "⭐",
    description: "Expert hair specialists",
    rating: 4.8,
    reviews: 1100,
    locations: 14,
  },
];

// ===== Services Data =====
const services = [
  {
    id: 1,
    name: "Haircut & Styling",
    icon: "✂️",
    description: "Professional haircut with expert styling",
    price: 599,
    duration: "45 mins",
  },
  {
    id: 2,
    name: "Hair Coloring",
    icon: "🎨",
    description: "Premium color treatment with top brands",
    price: 2499,
    duration: "2 hours",
  },
  {
    id: 3,
    name: "Hair Spa",
    icon: "💆",
    description: "Relaxing hair spa therapy",
    price: 1299,
    duration: "1 hour",
  },
  {
    id: 4,
    name: "Facial Treatment",
    icon: "✨",
    description: "Deep cleansing facial for glowing skin",
    price: 899,
    duration: "45 mins",
  },
  {
    id: 5,
    name: "Makeup",
    icon: "💄",
    description: "Professional makeup for all occasions",
    price: 1999,
    duration: "1.5 hours",
  },
  {
    id: 6,
    name: "Manicure & Pedicure",
    icon: "💅",
    description: "Complete nail care and styling",
    price: 799,
    duration: "1 hour",
  },
  {
    id: 7,
    name: "Hair Smoothening",
    icon: "🌟",
    description: "Keratin smoothening treatment",
    price: 3999,
    duration: "3 hours",
  },
  {
    id: 8,
    name: "Bridal Package",
    icon: "👰",
    description: "Complete bridal makeover",
    price: 9999,
    duration: "4 hours",
  },
];

// ===== Hairstyles Data =====
const hairstyles = [
  {
    id: 1,
    name: "Classic Bob",
    category: "women",
    image: "bob.jpg",
    trending: true,
  },
  {
    id: 2,
    name: "Layered Cut",
    category: "women",
    image: "layered.jpg",
    trending: false,
  },
  {
    id: 3,
    name: "Pixie Cut",
    category: "women",
    image: "pixie.jpg",
    trending: true,
  },
  {
    id: 4,
    name: "Long Waves",
    category: "women",
    image: "waves.jpg",
    trending: false,
  },
  {
    id: 5,
    name: "Buzz Cut",
    category: "men",
    image: "buzz.jpg",
    trending: false,
  },
  { id: 6, name: "Fade", category: "men", image: "fade.jpg", trending: true },
  {
    id: 7,
    name: "Pompadour",
    category: "men",
    image: "pompadour.jpg",
    trending: true,
  },
  {
    id: 8,
    name: "Undercut",
    category: "men",
    image: "undercut.jpg",
    trending: false,
  },
];

// ===== Helper Functions =====
function showNotification(message, type = "success") {
  const notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.innerHTML = `
        <i class="fas ${
          type === "success" ? "fa-check-circle" : "fa-exclamation-circle"
        }"></i>
        <span>${message}</span>
    `;
  notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 24px;
        background: ${
          type === "success"
            ? "linear-gradient(135deg, #10B981 0%, #059669 100%)"
            : "linear-gradient(135deg, #EF4444 0%, #DC2626 100%)"
        };
        color: white;
        padding: 16px 24px;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        z-index: 10001;
        display: flex;
        align-items: center;
        gap: 12px;
        font-weight: 600;
        animation: slideInRight 0.3s ease-out;
    `;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.animation = "slideOutRight 0.3s ease-out";
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// Unicode-safe base64 encoder for SVG/data URIs (handles emojis/unicode)
function toBase64Unicode(str) {
  return btoa(unescape(encodeURIComponent(str)));
}

// Face detection / hairstyle overlay state
let faceModel = null;
let faceModelLoaded = false;
let faceModelType = null; // 'landmarks' or 'bbox'

async function loadFaceModel() {
  if (faceModelLoaded) return;
  try {
    // Try to load face-landmarks first (if available), otherwise fall back to blazeface
    if (typeof faceLandmarksDetection !== "undefined" && faceLandmarksDetection.load) {
      // If SupportedPackages exists, prefer mediapipeFacemesh, else call load with no args
      let pkg = null;
      try {
        pkg =
          (faceLandmarksDetection.SupportedPackages &&
            (faceLandmarksDetection.SupportedPackages.mediapipeFacemesh ||
              faceLandmarksDetection.SupportedPackages.tfjs)) || null;
      } catch (e) {
        pkg = null;
      }

      if (pkg) {
        faceModel = await faceLandmarksDetection.load(pkg);
      } else {
        faceModel = await faceLandmarksDetection.load();
      }
      faceModelType = "landmarks";
      faceModelLoaded = true;
      console.log("Face landmarks model loaded");
    } else if (typeof blazeface !== "undefined" && blazeface.load) {
      faceModel = await blazeface.load();
      faceModelType = "bbox";
      faceModelLoaded = true;
      console.log("Blazeface model loaded as fallback");
    } else {
      throw new Error("No face detection models available in page scope");
    }
  } catch (err) {
    console.error("Failed to load face model:", err);
  }
}

function getHairstyleImgSrc(styleId) {
  const item = document.querySelector(`.hairstyle-item[data-style-id="${styleId}"] img`);
  return item ? item.src : null;
}

async function applyHairstyleToCanvas(styleId) {
  const imgSrc = getHairstyleImgSrc(styleId);
  if (!imgSrc) return;

  const context = canvas.getContext("2d");
  // Ensure there's an image already on the canvas (captured/uploaded)
  // We'll read current canvas pixels and redraw overlay on top

  // Load hairstyle image
  const hairImg = new Image();
  hairImg.crossOrigin = "anonymous";
  hairImg.src = imgSrc;
  await new Promise((res, rej) => {
    hairImg.onload = res;
    hairImg.onerror = rej;
  }).catch(() => {
    console.error("Failed to load hairstyle image");
    return;
  });

  // If face model available, try to position hair relative to detected face
  let drawX = 0,
    drawY = 0,
    drawW = hairImg.width,
    drawH = hairImg.height;

  if (faceModelLoaded && faceModel && webcam && (webcam.srcObject || webcam.videoWidth)) {
    try {
      const predictions =
        faceModelType === "landmarks"
          ? await faceModel.estimateFaces({
              input: webcam,
              returnTensors: false,
              flipHorizontal: true,
            })
          : await faceModel.estimateFaces(webcam, false);

      if (predictions && predictions.length > 0) {
        const p = predictions[0];

        // If landmarks (mesh) available, compute bbox from mesh
        if (p.scaledMesh || p.mesh) {
          const keypoints = p.scaledMesh || p.mesh || [];
          let minX = Infinity,
            minY = Infinity,
            maxX = -Infinity,
            maxY = -Infinity;
          keypoints.forEach((pt) => {
            const [x, y] = pt;
            if (x < minX) minX = x;
            if (y < minY) minY = y;
            if (x > maxX) maxX = x;
            if (y > maxY) maxY = y;
          });

          const faceW = maxX - minX;
          const centerX = minX + faceW / 2;

          drawW = faceW * 1.6;
          const aspect = hairImg.width / hairImg.height;
          drawH = drawW / aspect;
          drawX = centerX - drawW / 2;
          drawY = minY - drawH * 0.55;
        } else if (p.topLeft && p.bottomRight) {
          // blazeface bbox
          const [tlx, tly] = p.topLeft;
          const [brx, bry] = p.bottomRight;
          const faceW = brx - tlx;
          const centerX = tlx + faceW / 2;

          drawW = faceW * 1.6;
          const aspect = hairImg.width / hairImg.height;
          drawH = drawW / aspect;
          drawX = centerX - drawW / 2;
          drawY = tly - drawH * 0.6;
        }
      }
    } catch (err) {
      console.warn("Face detection failed:", err);
    }
  }

  // If webcam capture was used, canvas already has photo; clear and redraw
  // We'll assume the current canvas contains the photo to overlay on
  // Draw hairstyle
  context.drawImage(hairImg, drawX, drawY, drawW, drawH);

  showNotification("Hairstyle applied to preview");
}

function formatCurrency(amount) {
  return `₹${amount.toLocaleString("en-IN")}`;
}

function generateBookingId() {
  return (
    "BB" +
    Date.now().toString(36).toUpperCase() +
    Math.random().toString(36).substring(2, 7).toUpperCase()
  );
}

// ===== Preloader =====
window.addEventListener("load", () => {
  setTimeout(() => {
    document.getElementById("preloader").classList.add("hidden");
  }, 2000);
});

// ===== Navigation =====
const navbar = document.getElementById("navbar");
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");
const navLinks = document.querySelectorAll(".nav-link");

window.addEventListener("scroll", () => {
  if (window.scrollY > 50) {
    navbar.classList.add("scrolled");
  } else {
    navbar.classList.remove("scrolled");
  }
});

hamburger.addEventListener("click", () => {
  navMenu.classList.toggle("active");
  hamburger.classList.toggle("active");
});

navLinks.forEach((link) => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const targetId = link.getAttribute("href");
    const targetSection = document.querySelector(targetId);

    if (targetSection) {
      targetSection.scrollIntoView({ behavior: "smooth" });
      navMenu.classList.remove("active");
      hamburger.classList.remove("active");

      navLinks.forEach((l) => l.classList.remove("active"));
      link.classList.add("active");
    }
  });
});

// ===== Generate Hero Image =====
const heroImage = document.getElementById("heroImage");
heroImage.src =
  "data:image/svg+xml;base64," +
  toBase64Unicode(`
<svg width="600" height="600" xmlns="http://www.w3.org/2000/svg">
    <defs>
        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#FF6B9D;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#8B5CF6;stop-opacity:1" />
        </linearGradient>
    </defs>
    <rect width="600" height="600" fill="url(#grad1)"/>
    <text x="50%" y="50%" font-family="Arial" font-size="60" fill="white" text-anchor="middle" dominant-baseline="middle">✨ Beauty</text>
</svg>
`);

// ===== Load Brands =====
function loadBrands() {
  const brandsGrid = document.getElementById("brandsGrid");
  const brandSelect = document.getElementById("brandSelect");

  brandsGrid.innerHTML = brands
    .map(
      (brand) => `
        <div class="brand-card" data-brand-id="${brand.id}">
            <div class="brand-logo">${brand.icon}</div>
            <h3>${brand.name}</h3>
            <p>${brand.description}</p>
            <div class="brand-rating">
                <i class="fas fa-star"></i>
                <span>${brand.rating}</span>
                <span>(${brand.reviews} reviews)</span>
            </div>
            <div class="brand-info">
                <div class="brand-info-item">
                    <strong>${brand.locations}</strong>
                    <span>Locations</span>
                </div>
                <div class="brand-info-item">
                    <strong>${brand.rating}</strong>
                    <span>Rating</span>
                </div>
            </div>
        </div>
    `
    )
    .join("");

  brandSelect.innerHTML =
    '<option value="">Select a brand...</option>' +
    brands
      .map((brand) => `<option value="${brand.id}">${brand.name}</option>`)
      .join("");

  // Brand card click handlers
  document.querySelectorAll(".brand-card").forEach((card) => {
    card.addEventListener("click", () => {
      const brandId = parseInt(card.dataset.brandId);
      appState.selectedBrand = brands.find((b) => b.id === brandId);
      showNotification(`${appState.selectedBrand.name} selected!`);
      document.getElementById("book").scrollIntoView({ behavior: "smooth" });
      brandSelect.value = brandId;
    });
  });
}

// ===== Load Services =====
function loadServices() {
  const servicesGrid = document.getElementById("servicesGrid");
  const serviceCheckboxes = document.getElementById("serviceCheckboxes");

  servicesGrid.innerHTML = services
    .map(
      (service) => `
        <div class="service-card" data-service-id="${service.id}">
            <div class="service-icon">${service.icon}</div>
            <h3>${service.name}</h3>
            <p>${service.description}</p>
            <div class="service-price">${formatCurrency(service.price)}</div>
            <div class="service-duration"><i class="fas fa-clock"></i> ${
              service.duration
            }</div>
        </div>
    `
    )
    .join("");

  serviceCheckboxes.innerHTML = services
    .map(
      (service) => `
        <div class="checkbox-item" data-service-id="${service.id}">
            <div>
                <strong>${service.name}</strong>
                <div style="color: var(--text-secondary); font-size: 14px;">
                    ${formatCurrency(service.price)} • ${service.duration}
                </div>
            </div>
            <input type="checkbox" value="${service.id}">
        </div>
    `
    )
    .join("");

  // Service checkbox handlers
  document.querySelectorAll(".checkbox-item").forEach((item) => {
    const checkbox = item.querySelector('input[type="checkbox"]');

    item.addEventListener("click", (e) => {
      if (e.target !== checkbox) {
        checkbox.checked = !checkbox.checked;
      }

      const serviceId = parseInt(item.dataset.serviceId);
      if (checkbox.checked) {
        item.classList.add("selected");
        if (!appState.selectedServices.includes(serviceId)) {
          appState.selectedServices.push(serviceId);
        }
      } else {
        item.classList.remove("selected");
        appState.selectedServices = appState.selectedServices.filter(
          (id) => id !== serviceId
        );
      }

      updateBookingPreview();
    });
  });
}

// ===== Load Hairstyles =====
function loadHairstyles() {
  const hairstylesGrid = document.getElementById("hairstylesGrid");
  const categoryBtns = document.querySelectorAll(".category-btn");

  function renderHairstyles(category = "all") {
    const filtered =
      category === "all"
        ? hairstyles
        : category === "trending"
        ? hairstyles.filter((h) => h.trending)
        : hairstyles.filter((h) => h.category === category);

    hairstylesGrid.innerHTML = filtered
      .map(
        (style) => `
            <div class="hairstyle-item" data-style-id="${style.id}">
                <img src="data:image/svg+xml;base64,${toBase64Unicode(`
                    <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                            <linearGradient id="grad${
                              style.id
                            }" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#${Math.random()
                                  .toString(16)
                                  .slice(2, 8)};stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#${Math.random()
                                  .toString(16)
                                  .slice(2, 8)};stop-opacity:1" />
                            </linearGradient>
                        </defs>
                        <rect width="200" height="200" fill="url(#grad${
                          style.id
                        })"/>
                        <text x="50%" y="50%" font-family="Arial" font-size="60" fill="white" text-anchor="middle" dominant-baseline="middle">${
                          style.category === "men" ? "👨" : "👩"
                        }</text>
                    </svg>
                `)}" alt="${style.name}">
                <div class="hairstyle-overlay">${style.name}</div>
            </div>
        `
      )
      .join("");

    // Add click handlers
    document.querySelectorAll(".hairstyle-item").forEach((item) => {
      item.addEventListener("click", () => {
        const styleId = parseInt(item.dataset.styleId);
        const selectedStyle = hairstyles.find((s) => s.id === styleId);
        
        // Open lightbox modal
        const lightbox = document.getElementById("photoLightbox");
        const lightboxImage = document.getElementById("lightboxImage");
        const lightboxCaption = document.getElementById("lightboxCaption");
        
        // Get the image source from the clicked item
        const imgSrc = item.querySelector("img").src;
        lightboxImage.src = imgSrc;
        lightboxCaption.textContent = selectedStyle.name;
        
        // Store the selected style ID for later use
        lightbox.dataset.selectedStyleId = styleId;
        
        // Show the lightbox
        lightbox.classList.add("active");
      });
    });
  }

  renderHairstyles();

  categoryBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      categoryBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      renderHairstyles(btn.dataset.category);
    });
  });
}

// ===== AI Camera Functions =====
const startCameraBtn = document.getElementById("startCameraBtn");
const stopCameraBtn = document.getElementById("stopCameraBtn");
const captureBtn = document.getElementById("captureBtn");
const uploadPhotoBtn = document.getElementById("uploadPhotoBtn");
const photoUpload = document.getElementById("photoUpload");
const webcam = document.getElementById("webcam");
const canvas = document.getElementById("canvas");
const cameraOverlay = document.getElementById("cameraOverlay");
const faceIndicator = document.getElementById("faceIndicator");

startCameraBtn.addEventListener("click", async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user", width: 1280, height: 720 },
    });

    webcam.srcObject = stream;
    appState.webcamStream = stream;
    appState.cameraActive = true;

    cameraOverlay.classList.add("hidden");
    startCameraBtn.style.display = "none";
    stopCameraBtn.style.display = "inline-flex";
    captureBtn.style.display = "inline-flex";

    showNotification("Camera started successfully!");

    // Initialize face detection
    initFaceDetection();
  } catch (error) {
    showNotification(
      "Failed to access camera. Please check permissions.",
      "error"
    );
    console.error("Camera error:", error);
  }
});

stopCameraBtn.addEventListener("click", () => {
  if (appState.webcamStream) {
    appState.webcamStream.getTracks().forEach((track) => track.stop());
    webcam.srcObject = null;
    appState.webcamStream = null;
    appState.cameraActive = false;

    cameraOverlay.classList.remove("hidden");
    startCameraBtn.style.display = "inline-flex";
    stopCameraBtn.style.display = "none";
    captureBtn.style.display = "none";
    faceIndicator.classList.remove("active");

    showNotification("Camera stopped");
  }
});

captureBtn.addEventListener("click", () => {
  const context = canvas.getContext("2d");
  canvas.width = webcam.videoWidth;
  canvas.height = webcam.videoHeight;
  context.drawImage(webcam, 0, 0);

  showNotification("Photo captured! Apply hairstyle from the gallery.");
});

uploadPhotoBtn.addEventListener("click", () => {
  photoUpload.click();
});

photoUpload.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const context = canvas.getContext("2d");
        canvas.width = img.width;
        canvas.height = img.height;
        context.drawImage(img, 0, 0);

        cameraOverlay.classList.add("hidden");
        showNotification("Photo uploaded successfully!");
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  }
});

// Face detection simulation
async function initFaceDetection() {
  await loadFaceModel();

  // Start lightweight detection loop
  const detectLoop = async () => {
    if (!appState.cameraActive) {
      faceIndicator.classList.remove("active");
      appState.faceDetected = false;
      return;
    }

    try {
          if (faceModelLoaded && faceModel) {
            let preds = [];
            try {
              if (faceModelType === "landmarks") {
                preds = await faceModel.estimateFaces({
                  input: webcam,
                  returnTensors: false,
                  flipHorizontal: true,
                });
              } else if (faceModelType === "bbox") {
                // blazeface signature
                preds = await faceModel.estimateFaces(webcam, false);
              }

              if (preds && preds.length > 0) {
                appState.faceDetected = true;
                faceIndicator.classList.add("active");
              } else {
                appState.faceDetected = false;
                faceIndicator.classList.remove("active");
              }
            } catch (e) {
              console.warn("Face model estimate error:", e);
            }
          }
    } catch (err) {
      console.warn("Face detection loop error:", err);
    }

    setTimeout(detectLoop, 400);
  };

  detectLoop();
}

// ===== Customization Controls =====
document.querySelectorAll(".color-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document
      .querySelectorAll(".color-btn")
      .forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    appState.selectedColor = btn.dataset.color;
  });
});

document.getElementById("hairLength").addEventListener("input", (e) => {
  appState.hairLength = e.target.value;
});

document.getElementById("styleIntensity").addEventListener("input", (e) => {
  appState.styleIntensity = e.target.value;
});

document
  .getElementById("applyCustomizationBtn")
  .addEventListener("click", () => {
    showNotification("Customization applied!");
  });

document.getElementById("bookThisStyleBtn").addEventListener("click", () => {
  // If a hairstyle was applied, ensure it's in the booking preview and then scroll
  if (appState.selectedHairstyle) {
    updateBookingPreview();
  }
  document.getElementById("book").scrollIntoView({ behavior: "smooth" });
});

document.getElementById("shareStyleBtn").addEventListener("click", () => {
  if (navigator.share) {
    navigator.share({
      title: "My New Hairstyle",
      text: "Check out my new hairstyle on BeautyBook!",
      url: window.location.href,
    });
  } else {
    showNotification("Sharing feature not supported on this browser", "error");
  }
});

document.getElementById("saveStyleBtn").addEventListener("click", () => {
  showNotification("Hairstyle saved to favorites!");
});

// ===== Booking Form =====
const bookingForm = document.getElementById("bookingForm");
let currentStep = 1;

function showStep(step) {
  document
    .querySelectorAll(".form-step")
    .forEach((s) => s.classList.remove("active"));
  document.getElementById(`step${step}`).classList.add("active");
  currentStep = step;
}

function updateBookingPreview() {
  const preview = document.getElementById("bookingPreview");

  if (appState.selectedServices.length === 0) {
    preview.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <p>Start booking to see summary</p>
            </div>
        `;
    return;
  }

  const selectedServiceObjects = services.filter((s) =>
    appState.selectedServices.includes(s.id)
  );
  const totalPrice = selectedServiceObjects.reduce(
    (sum, s) => sum + s.price,
    0
  );

  preview.innerHTML = `
        <div style="margin-bottom: 20px;">
            <strong>Selected Services:</strong>
            <ul style="margin-top: 10px; padding-left: 20px;">
                ${selectedServiceObjects
                  .map((s) => `<li>${s.name} - ${formatCurrency(s.price)}</li>`)
                  .join("")}
            </ul>
        </div>
        ${
          appState.selectedBrand
            ? `<div style="margin-bottom: 10px;"><strong>Brand:</strong> ${appState.selectedBrand.name}</div>`
            : ""
        }
        ${
          appState.selectedDate
            ? `<div style="margin-bottom: 10px;"><strong>Date:</strong> ${appState.selectedDate}</div>`
            : ""
        }
        ${
          appState.selectedTime
            ? `<div style="margin-bottom: 10px;"><strong>Time:</strong> ${appState.selectedTime}</div>`
            : ""
        }
        <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--border-color);">
            <strong style="font-size: 20px; color: var(--primary);">Total: ${formatCurrency(
              totalPrice
            )}</strong>
        </div>
    `;
  // If a hairstyle is selected, show it in the preview
  if (appState.selectedHairstyle) {
    const styleImgSrc = getHairstyleImgSrc(appState.selectedHairstyle.id);
    const thumb = styleImgSrc
      ? `<img src="${styleImgSrc}" alt="${appState.selectedHairstyle.name}" style="width:64px;height:64px;object-fit:cover;border-radius:8px;margin-top:12px;">`
      : "";

    preview.innerHTML += `
        <div style="margin-top:12px; display:flex; align-items:center; gap:12px;">
            ${thumb}
            <div>
                <strong>Selected Hairstyle</strong>
                <div style="color:var(--text-secondary);">${appState.selectedHairstyle.name}</div>
            </div>
        </div>
    `;
  }
}

// Generate time slots
function generateTimeSlots() {
  const timeSlotsContainer = document.getElementById("timeSlots");
  const slots = [];

  for (let hour = 9; hour <= 19; hour++) {
    for (let min of ["00", "30"]) {
      const time = `${hour.toString().padStart(2, "0")}:${min}`;
      const displayTime =
        hour > 12 ? `${hour - 12}:${min} PM` : `${hour}:${min} AM`;
      slots.push({ time, displayTime });
    }
  }

  timeSlotsContainer.innerHTML = slots
    .map(
      (slot) => `
        <div class="time-slot" data-time="${slot.time}">${slot.displayTime}</div>
    `
    )
    .join("");

  document.querySelectorAll(".time-slot").forEach((slot) => {
    slot.addEventListener("click", () => {
      document
        .querySelectorAll(".time-slot")
        .forEach((s) => s.classList.remove("selected"));
      slot.classList.add("selected");
      appState.selectedTime = slot.dataset.time;
      updateBookingPreview();
    });
  });
}

// Set minimum date to today
const bookingDateInput = document.getElementById("bookingDate");
bookingDateInput.min = new Date().toISOString().split("T")[0];
bookingDateInput.addEventListener("change", (e) => {
  appState.selectedDate = e.target.value;
  updateBookingPreview();
});

// Step navigation
document.getElementById("step1Next").addEventListener("click", () => {
  const brandSelect = document.getElementById("brandSelect");

  if (!brandSelect.value) {
    showNotification("Please select a brand", "error");
    return;
  }

  if (appState.selectedServices.length === 0) {
    showNotification("Please select at least one service", "error");
    return;
  }

  appState.selectedBrand = brands.find(
    (b) => b.id === parseInt(brandSelect.value)
  );
  showStep(2);
  generateTimeSlots();
});

document
  .getElementById("step2Back")
  .addEventListener("click", () => showStep(1));

document.getElementById("step2Next").addEventListener("click", () => {
  if (!appState.selectedDate) {
    showNotification("Please select a date", "error");
    return;
  }

  if (!appState.selectedTime) {
    showNotification("Please select a time slot", "error");
    return;
  }

  showStep(3);
});

document
  .getElementById("step3Back")
  .addEventListener("click", () => showStep(2));

document.getElementById("step3Next").addEventListener("click", () => {
  const name = document.getElementById("customerName").value;
  const phone = document.getElementById("customerPhone").value;

  if (!name || !phone) {
    showNotification("Please fill in required fields", "error");
    return;
  }

  showStep(4);
  updateBookingSummary();
});

document
  .getElementById("step4Back")
  .addEventListener("click", () => showStep(3));

// Payment options
document.querySelectorAll(".payment-option").forEach((option) => {
  option.addEventListener("click", () => {
    document
      .querySelectorAll(".payment-option")
      .forEach((o) => o.classList.remove("selected"));
    option.classList.add("selected");
    appState.paymentMethod = option.dataset.payment;
  });
});

// Update booking summary
function updateBookingSummary() {
  const summaryContainer = document.getElementById("bookingSummary");
  const selectedServiceObjects = services.filter((s) =>
    appState.selectedServices.includes(s.id)
  );
  const totalPrice = selectedServiceObjects.reduce(
    (sum, s) => sum + s.price,
    0
  );

  summaryContainer.innerHTML = `
        <div class="summary-item">
            <span>Services (${selectedServiceObjects.length})</span>
            <span>${formatCurrency(totalPrice)}</span>
        </div>
        <div class="summary-item">
            <span>GST (18%)</span>
            <span>${formatCurrency(Math.round(totalPrice * 0.18))}</span>
        </div>
        <div class="summary-item">
            <strong>Total Amount</strong>
            <strong>${formatCurrency(Math.round(totalPrice * 1.18))}</strong>
        </div>
    `;
}

// Form submission
bookingForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const selectedServiceObjects = services.filter((s) =>
    appState.selectedServices.includes(s.id)
  );
  const totalPrice = Math.round(
    selectedServiceObjects.reduce((sum, s) => sum + s.price, 0) * 1.18
  );

  appState.bookingData = {
    bookingId: generateBookingId(),
    brand: appState.selectedBrand,
    services: selectedServiceObjects,
    date: appState.selectedDate,
    time: appState.selectedTime,
    customer: {
      name: document.getElementById("customerName").value,
      phone: document.getElementById("customerPhone").value,
      email: document.getElementById("customerEmail").value,
      requests: document.getElementById("specialRequests").value,
    },
    totalAmount: totalPrice,
    paymentMethod: appState.paymentMethod,
    timestamp: new Date().toISOString(),
  };

  processPayment();
});

// Process payment
function processPayment() {
  const amount = appState.bookingData.totalAmount;

  if (appState.paymentMethod === "online") {
    // Razorpay integration
    const options = {
      key: "rzp_test_1234567890", // Replace with actual Razorpay key
      amount: amount * 100, // Amount in paise
      currency: "INR",
      name: "BeautyBook",
      description: "Salon Booking Payment",
      image: "https://example.com/logo.png",
      handler: function (response) {
        appState.bookingData.paymentId = response.razorpay_payment_id;
        confirmBooking();
      },
      prefill: {
        name: appState.bookingData.customer.name,
        email: appState.bookingData.customer.email,
        contact: appState.bookingData.customer.phone,
      },
      theme: {
        color: "#FF6B9D",
      },
    };

    // Simulate Razorpay payment
    showNotification("Opening payment gateway...");
    setTimeout(() => {
      appState.bookingData.paymentId =
        "pay_" + Math.random().toString(36).substring(7);
      confirmBooking();
    }, 1500);
  } else if (appState.paymentMethod === "upi") {
    showQRCode(amount);
  } else {
    confirmBooking();
  }
}

// Show QR code for UPI payment
function showQRCode(amount) {
  const modal = document.getElementById("qrModal");
  const qrcodeContainer = document.getElementById("qrcode");

  qrcodeContainer.innerHTML = "";

  // Generate QR code
  new QRCode(qrcodeContainer, {
    text: `upi://pay?pa=beautybook@upi&pn=BeautyBook&am=${amount}&cu=INR`,
    width: 250,
    height: 250,
  });

  document.getElementById("qrAmount").textContent = amount;
  modal.classList.add("active");
}

document.getElementById("confirmUPIPayment").addEventListener("click", () => {
  document.getElementById("qrModal").classList.remove("active");
  appState.bookingData.paymentId =
    "upi_" + Math.random().toString(36).substring(7);
  confirmBooking();
});

// Confirm booking
function confirmBooking() {
  const modal = document.getElementById("confirmationModal");
  const detailsContainer = document.getElementById("confirmationDetails");

  detailsContainer.innerHTML = `
        <div style="background: var(--bg-tertiary); padding: 24px; border-radius: 12px; margin: 24px 0; text-align: left;">
            <div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                <strong style="color: var(--primary);">Booking ID:</strong> ${
                  appState.bookingData.bookingId
                }
            </div>
            <div style="margin-bottom: 12px;">
                <strong>Brand:</strong> ${appState.bookingData.brand.name}
            </div>
            <div style="margin-bottom: 12px;">
                <strong>Date & Time:</strong> ${new Date(
                  appState.bookingData.date
                ).toLocaleDateString()} at ${appState.bookingData.time}
            </div>
            <div style="margin-bottom: 12px;">
                <strong>Services:</strong> ${appState.bookingData.services
                  .map((s) => s.name)
                  .join(", ")}
            </div>
            <div style="margin-bottom: 12px;">
                <strong>Amount Paid:</strong> ${formatCurrency(
                  appState.bookingData.totalAmount
                )}
            </div>
            ${
              appState.bookingData.paymentId
                ? `
                <div style="margin-bottom: 12px;">
                    <strong>Payment ID:</strong> ${appState.bookingData.paymentId}
                </div>
            `
                : ""
            }
        </div>
        <p style="color: var(--text-secondary);">A confirmation has been sent to your phone.</p>
    `;

  modal.classList.add("active");

  // Reset form
  bookingForm.reset();
  appState.selectedServices = [];
  showStep(1);
}

document.getElementById("downloadTicket").addEventListener("click", () => {
  const ticketData = JSON.stringify(appState.bookingData, null, 2);
  const blob = new Blob([ticketData], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `BeautyBook-Ticket-${appState.bookingData.bookingId}.json`;
  a.click();
  showNotification("Ticket downloaded successfully!");
});

document.getElementById("closeConfirmation").addEventListener("click", () => {
  document.getElementById("confirmationModal").classList.remove("active");
});

// ===== Modal Controls =====
document.querySelectorAll(".close-modal").forEach((btn) => {
  btn.addEventListener("click", () => {
    document
      .querySelectorAll(".modal")
      .forEach((modal) => modal.classList.remove("active"));
  });
});

window.addEventListener("click", (e) => {
  if (e.target.classList.contains("modal")) {
    e.target.classList.remove("active");
  }
});

// Login modal
document.getElementById("loginBtn").addEventListener("click", () => {
  document.getElementById("loginModal").classList.add("active");
});

document.getElementById("loginForm").addEventListener("submit", (e) => {
  e.preventDefault();
  showNotification("OTP sent to your phone!");
  setTimeout(() => {
    document.getElementById("loginModal").classList.remove("active");
    showNotification("Login successful!");
  }, 2000);
});

// Contact form
document.getElementById("contactForm").addEventListener("submit", (e) => {
  e.preventDefault();
  showNotification("Message sent successfully! We'll get back to you soon.");
  e.target.reset();
});

// ===== Quick Action Buttons =====
document.getElementById("bookNowBtn").addEventListener("click", () => {
  document.getElementById("book").scrollIntoView({ behavior: "smooth" });
});

document.getElementById("tryAIBtn").addEventListener("click", () => {
  document.getElementById("ai-tryon").scrollIntoView({ behavior: "smooth" });
});

document.getElementById("exploreBrandsBtn").addEventListener("click", () => {
  document.getElementById("brands").scrollIntoView({ behavior: "smooth" });
});

// ===== Initialize App =====
document.addEventListener("DOMContentLoaded", () => {
  loadBrands();
  loadServices();
  loadHairstyles();

  // Add animation styles
  const style = document.createElement("style");
  style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
  document.head.appendChild(style);

  console.log("BeautyBook application initialized successfully!");
  console.log("🎨 All features are fully functional");
  console.log("💇 AI Try-On Ready");
  console.log("💳 Payment Integration Ready");
  console.log("📱 QR Code Generation Ready");
});

// ===== Lightbox Modal Controls =====
document.getElementById("selectFromLightbox").addEventListener("click", () => {
  const lightbox = document.getElementById("photoLightbox");
  const styleId = parseInt(lightbox.dataset.selectedStyleId);
  
  if (styleId) {
    // Mark all hairstyle items
    document
      .querySelectorAll(".hairstyle-item")
      .forEach((i) => i.classList.remove("selected"));
    
    // Mark the selected one
    const selectedItem = document.querySelector(
      `.hairstyle-item[data-style-id="${styleId}"]`
    );
    if (selectedItem) {
      selectedItem.classList.add("selected");
    }
    
    // Update app state
    appState.selectedHairstyle = hairstyles.find((s) => s.id === styleId);
    showNotification(`${appState.selectedHairstyle.name} selected!`);
    
    // Close lightbox
    lightbox.classList.remove("active");
    // Apply hairstyle to current canvas/photo preview (if any)
    applyHairstyleToCanvas(styleId);
  }
});

document.getElementById("shareFromLightbox").addEventListener("click", () => {
  const lightbox = document.getElementById("photoLightbox");
  const styleId = parseInt(lightbox.dataset.selectedStyleId);
  const selectedStyle = hairstyles.find((s) => s.id === styleId);
  
  if (navigator.share) {
    navigator
      .share({
        title: `${selectedStyle.name} - BeautyBook`,
        text: `Check out this ${selectedStyle.name} hairstyle on BeautyBook!`,
        url: window.location.href,
      })
      .then(() => {
        showNotification("Shared successfully!");
      })
      .catch(() => {
        showNotification("Sharing cancelled", "error");
      });
  } else {
    // Fallback: copy to clipboard
    navigator.clipboard.writeText(window.location.href);
    showNotification("Link copied to clipboard!");
  }
});

// ===== Service Worker for PWA (Optional) =====
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => console.log("Service Worker registered"))
      .catch((err) => console.log("Service Worker registration failed"));
  });
}
