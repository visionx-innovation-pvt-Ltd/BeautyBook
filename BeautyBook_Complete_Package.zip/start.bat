@echo off
echo ========================================
echo    BeautyBook - Starting Application
echo ========================================
echo.

echo Checking for Node.js...
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Node.js not found! Opening with default browser...
    start index.html
    exit /b
)

echo Node.js found!
echo.
echo Installing dependencies (if needed)...
call npm install --silent

echo.
echo Starting development server...
echo.
echo Application will open at: http://localhost:3000
echo.
echo Press Ctrl+C to stop the server
echo.

call npm run dev
