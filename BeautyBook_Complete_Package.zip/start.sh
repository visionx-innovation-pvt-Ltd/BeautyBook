#!/bin/bash

echo "========================================"
echo "   BeautyBook - Starting Application"
echo "========================================"
echo ""

if ! command -v node &> /dev/null
then
    echo "Node.js not found! Opening with default browser..."
    open index.html  # macOS
    # xdg-open index.html  # Linux
    exit
fi

echo "Node.js found!"
echo ""
echo "Installing dependencies (if needed)..."
npm install --silent

echo ""
echo "Starting development server..."
echo ""
echo "Application will open at: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

npm run dev
