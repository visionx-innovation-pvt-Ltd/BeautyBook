# BeautyBook - Quick Start Guide

## 🎯 How to Run the Application

### Method 1: Direct Browser Open (Easiest)

1. Navigate to the folder: `d:\visionx innovation\xut`
2. Double-click on `index.html`
3. The application will open in your default browser
4. ✅ Everything works except camera (needs HTTPS/localhost server)

### Method 2: Using Start Script (Recommended)

1. Double-click `start.bat` (Windows) or `start.sh` (Mac/Linux)
2. Application will automatically open at `http://localhost:3000`
3. ✅ All features work including camera

### Method 3: Manual Server Start

```bash
# Navigate to project folder
cd "d:\visionx innovation\xut"

# Install dependencies (first time only)
npm install

# Start development server
npm run dev
```

---

## 🎨 Features Overview

### 1️⃣ **AI Virtual Try-On**

- Click "Try AI Virtual Try-On" button
- Allow camera access
- Browse hairstyles from gallery
- Click on any hairstyle to preview
- Customize color, length, and intensity
- Capture or upload photos

### 2️⃣ **Browse Salon Brands**

- Scroll to "Our Partner Salon Brands" section
- View 6 premium brands with ratings
- Click any brand card to select it
- Ratings, reviews, and locations displayed

### 3️⃣ **View Services**

- Scroll to "Premium Services" section
- 8 different services available
- Prices and durations shown
- Hover for interactive effects

### 4️⃣ **Book Appointment**

- Click "Book Now" button
- **Step 1:** Select brand and services (multiple selection)
- **Step 2:** Choose date and time slot
- **Step 3:** Enter your details
- **Step 4:** Select payment method
  - Online Payment (Razorpay)
  - UPI Payment (QR Code)
  - Cash on Arrival

### 5️⃣ **Payment Options**

#### Online Payment

- Integrated with Razorpay
- Secure card/UPI/netbanking
- Instant confirmation

#### UPI Payment

- QR code generated automatically
- Scan with any UPI app
- Click "I've Paid" to confirm

#### Cash on Arrival

- Pay at the salon
- No advance payment needed

### 6️⃣ **Booking Confirmation**

- Unique booking ID generated
- Complete booking details shown
- Download ticket option
- SMS confirmation (simulated)

---

## 🔧 Configuration Guide

### Setting Up Razorpay (For Live Payments)

1. Sign up at [Razorpay](https://razorpay.com)
2. Get your API Key
3. Edit `script.js` (line ~480):

```javascript
key: "YOUR_RAZORPAY_KEY_HERE";
```

### Setting Up UPI ID

Edit `script.js` (QR code generation section):

```javascript
text: `upi://pay?pa=YOUR_UPI_ID@provider&pn=BeautyBook&am=${amount}&cu=INR`;
```

Common UPI providers:

- `@paytm` - Paytm
- `@ybl` - PhonePe
- `@okhdfcbank` - HDFC Bank
- `@oksbi` - SBI

---

## 📱 Testing Payment Features

### Test Razorpay Integration

Currently using demo mode. Payments are simulated.

For real testing:

- Use Razorpay Test Mode
- Test Card: 4111 1111 1111 1111
- CVV: Any 3 digits
- Expiry: Any future date

### Test UPI QR Code

1. Book an appointment
2. Select "UPI Payment"
3. QR code will be generated
4. Use any UPI app to scan (in production)

---

## 🎯 Click & Test Features

### ✅ Everything is Functional!

**Navigation:**

- ✅ All menu links work
- ✅ Smooth scrolling
- ✅ Mobile hamburger menu

**AI Try-On:**

- ✅ Camera start/stop
- ✅ Photo upload
- ✅ Hairstyle selection
- ✅ Color picker
- ✅ Customization sliders
- ✅ Capture button

**Brand Selection:**

- ✅ All 6 brand cards clickable
- ✅ Ratings displayed
- ✅ Auto-scroll to booking

**Service Selection:**

- ✅ Multiple service selection
- ✅ Price calculation
- ✅ Real-time preview

**Booking Flow:**

- ✅ 4-step process
- ✅ Form validation
- ✅ Date picker (minimum today)
- ✅ Time slot selection
- ✅ Customer details form

**Payment:**

- ✅ 3 payment methods
- ✅ Payment method selection
- ✅ QR code generation
- ✅ Booking confirmation

**Modals:**

- ✅ Login modal
- ✅ QR code modal
- ✅ Confirmation modal
- ✅ Close buttons work

**Other Features:**

- ✅ Contact form
- ✅ Social media links
- ✅ Download ticket
- ✅ Notifications system

---

## 🎨 Customization

### Change Colors

Edit `styles.css` (line 1-50):

```css
:root {
  --primary: #ff6b9d; /* Change to your brand color */
  --secondary: #6366f1;
  --accent: #8b5cf6;
}
```

### Add More Brands

Edit `script.js` brands array:

```javascript
{
    id: 7,
    name: 'Your Salon',
    icon: '💎',
    description: 'Your description',
    rating: 4.9,
    reviews: 1000,
    locations: 10
}
```

### Add More Services

Edit `script.js` services array:

```javascript
{
    id: 9,
    name: 'Your Service',
    icon: '✨',
    description: 'Service description',
    price: 999,
    duration: '1 hour'
}
```

---

## 📱 Convert to Mobile App

### Using Capacitor (Recommended)

```bash
npm install -g @capacitor/cli
capacitor init BeautyBook com.beautybook.app
capacitor add android
capacitor add ios
```

### Using Cordova

```bash
npm install -g cordova
cordova create BeautyBook
cordova platform add android ios
cordova build
```

### PWA Installation

1. Open in Chrome/Edge
2. Click menu (...)
3. Select "Install BeautyBook"
4. App appears on desktop/home screen

---

## 🐛 Troubleshooting

### Camera Not Working

- Use HTTPS or localhost
- Check browser permissions
- Try different browser

### Payments Not Processing

- Using demo mode currently
- Add real Razorpay key for live payments
- Check console for errors

### Styles Not Loading

- Make sure all files are in same folder
- Check CSS file path
- Clear browser cache

### JavaScript Errors

- Open browser console (F12)
- Check for error messages
- Ensure all libraries loaded

---

## 🌐 Deployment

### GitHub Pages

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin YOUR_REPO_URL
git push -u origin main
```

Enable GitHub Pages in repository settings

### Netlify

1. Drag and drop folder to Netlify
2. Site published automatically
3. Free HTTPS included

### Vercel

```bash
npm install -g vercel
vercel
```

---

## 📊 Browser Compatibility

| Browser | Status  | Notes             |
| ------- | ------- | ----------------- |
| Chrome  | ✅ Full | Recommended       |
| Firefox | ✅ Full | All features work |
| Safari  | ✅ Full | iOS compatible    |
| Edge    | ✅ Full | Chromium-based    |
| Opera   | ✅ Full | Chromium-based    |

---

## 🎯 Next Steps

1. ✅ Test all features
2. ✅ Customize branding
3. ✅ Add your payment details
4. ✅ Deploy to hosting
5. ✅ Connect backend (optional)
6. ✅ Add real salon data
7. ✅ Launch marketing

---

## 💡 Tips

- Test on mobile devices
- Check all form validations
- Try different payment methods
- Test camera on different devices
- Use real salon images (replace SVG placeholders)
- Add Google Maps integration for locations
- Connect to WhatsApp for booking confirmations

---

## 📞 Support

If you need help:

1. Check this guide
2. Read README.md
3. Check browser console for errors
4. Review code comments

---

**Happy Booking! 💇✨**
